   <!-- Side-Nav -->
   <div class="side-navbar active-nav d-flex justify-content-between flex-wrap flex-column"
       id="sidebar">
       <ul class="nav flex-column text-white w-100">
           <a href="#" class="nav-link h3 text-white my-2">
               Responsive </br>SideBar Nav
           </a>
           <li href="#" class="nav-link">
               <i class="bx bxs-dashboard"></i>
               <span class="mx-2">Home</span>
           </li>
           <li href="#" class="nav-link">
               <i class="bx bx-user-check"></i>
               <span class="mx-2">Profile</span>
           </li>
           <li href="#" class="nav-link">
               <i class="bx bx-conversation"></i>
               <span class="mx-2">Contact</span>
           </li>
       </ul>

       <span href="#" class="nav-link h4 w-100 mb-5">
           <a href=""><i class="bx bxl-instagram-alt text-white"></i></a>
           <a href=""><i class="bx bxl-twitter px-2 text-white"></i></a>
           <a href=""><i class="bx bxl-facebook text-white"></i></a>
       </span>
   </div>

   <!-- Main Wrapper -->
   <div class="p-1 my-container active-cont">
       <!-- Top Nav -->
       <nav class="navbar top-navbar navbar-light bg-success px-5 pt-4 pb-4">
           <a class="btn border-0" id="menu-btn"><i class="bx bx-menu"></i></a>
       </nav>
       <!--End Top Nav -->
       <h3 class="text-dark p-3">RESPONSIVE SIDEBAR NAV 💻 📱
       </h3>
       <p class="px-3">Responsive navigation sidebar built using
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue tortor eget pulvinar
           lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
           cubilia Curae; Nam ac dolor augue. Pellentesque mi mi, laoreet et dolor sit amet,
           ultrices varius risus. Nam vitae iaculis elit. Aliquam mollis interdum libero. Sed
           sodales placerat egestas. Vestibulum ut arcu aliquam purus viverra dictum vel sit amet
           mi. Duis nisl mauris, aliquam sit amet luctus eget, dapibus in enim. Sed velit augue,
           pretium a sem aliquam, congue porttitor tortor. Sed tempor nisl a lorem consequat, id
           maximus erat aliquet. Sed sagittis porta libero sed condimentum. Aliquam finibus lectus
           nec ante congue rutrum. Curabitur quam quam, accumsan id ultrices ultrices, tempor et
           tellus.
           
           <a class="text-dark" href="https://getbootstrap.com/">Bootstrap 5</a>.
       </p>
   </div>
   <script>
var menu_btn = document.querySelector("#menu-btn");
var sidebar = document.querySelector("#sidebar");
var container = document.querySelector(".my-container");
menu_btn.addEventListener("click", () => {
    sidebar.classList.toggle("active-nav");
    container.classList.toggle("active-cont");
});
   </script>
   <style>
.side-navbar {
    width: 200px;
    height: 100%;
    position: fixed;
    margin-left: -300px;
    background-color: #100901;
    transition: 0.5s;
}

.nav-link:active,
.nav-link:focus,
.nav-link:hover {
    background-color: #ffffff26;
}

.my-container {
    transition: 0.4s;
}

.active-nav {
    margin-left: 0;
}

/* for main section */
.active-cont {
    margin-left: 200px;

}

#menu-btn {
    background-color: #100901;
    color: #fff;
    margin-left: -62px;
}

.my-container input {
    border-radius: 2rem;
    padding: 2px 20px;
}
   </style>