<div class="container container_space">
    <div class="row mt-5 mb-5">
       <div class="col-4">
       <div class="title_header">
            <span class="title_header_item">Lịch trình</span>
        </div>
       </div>
       <div class="col-8">
       <div class="data">
       <div class="glass-panel">
  <h1><a href="https://superdevresources.com/glassmorphism-ui-css/" target="_blank">Glassmorphism CSS Panels and Buttons</a></h1>
  <p>Glassmorphism is achieved using transparency and background blur to get a frosted-glass like effect.</p>
  <div class="glass-toolbar">
    <button class="glass-button">Glass Button</button>
    <a href="https://superdevresources.com/glassmorphism-ui-css/" target="_blank" class="glass-button">Glass Link Button</a>
  </div>
</div>
       </div>
       </div>
    </div>
</div>
<script src="../Views/javascript/tasksView/fetchAll.js"></script>