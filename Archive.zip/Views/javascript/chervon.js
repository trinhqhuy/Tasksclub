function myFunction(x) {
    x.classList.toggle("bi-chevron-up");
  } 
  function slide() {
    var col8 = document.querySelector('.col-8')
    col8.className = 'col-6 main'
  }