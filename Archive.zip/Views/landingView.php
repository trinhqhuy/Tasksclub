<div class="container">
<div class="row landing_row">
    <div class="col-7 py-5">
        <h1 class="mt-5">Quản lý công việc <span class="typed-text"></span><span class="cursor">|</span></h1>
        <p class="d-flex fs-4 mx-auto mt-5 mb-5 lh-lg">Giúp bạn quản lý công việc dưới dạng nhóm, danh sách, thẻ</br>
            Thống kê chi tiết công việc hoàn thành, nhắc nhở</br>
            Cho phép bạn sử dụng ngay khi đăng ký</p>
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
    <div class="col-5 d-flex align-items-center">
        <div class="justify-content-center">
            <img class="landing_image" src="../Views/assets/landing_image3.png" width="100%">
        </div>
    </div>
</div>
</div>